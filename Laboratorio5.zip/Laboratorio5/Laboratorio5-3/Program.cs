﻿using System;

namespace Laboratorio5_3
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] frutas = { "manzana", "plátano", "naranja" };

            foreach (var fruta in frutas)
            {
                Console.WriteLine(fruta);
            }

        }
    }
}
